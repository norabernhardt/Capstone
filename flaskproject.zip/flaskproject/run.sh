#!/bin/bash

export FLASK_APP=flaskr
export FLASK_ENV=development
flask run